import { useState, useEffect, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  HeartPulse, 
  Thermometer, 
  Wind, 
  Activity, 
  Syringe, 
  ChevronRight, 
  RotateCcw, 
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  Stethoscope
} from "lucide-react";

interface VitalFinding {
  label: string;
  detail: string;
  level: "good" | "warning" | "danger";
  icon: ReactNode;
}

interface AnalysisResult {
  findings: VitalFinding[];
  overall: "good" | "low-warning" | "moderate" | "high" | "critical";
  message: {
    label: string;
    emoji: string;
    advice: string;
    bg: string;
    border: string;
    icon: ReactNode;
  };
}

function analyzeVitals(form: any): AnalysisResult {
  const hr = parseFloat(form.heartRate);
  const sp = parseFloat(form.spo2);
  const temp = parseFloat(form.temperature);
  const resp = parseFloat(form.respRate);
  const sys = parseFloat(form.systolic);
  const dia = parseFloat(form.diastolic);

  const findings: VitalFinding[] = [];

  // Heart Rate
  if (hr > 120) findings.push({ label: "High Heart Rate", detail: `${hr} bpm — above normal`, level: "danger", icon: <HeartPulse className="w-5 h-5" /> });
  else if (hr > 100) findings.push({ label: "Elevated Heart Rate", detail: `${hr} bpm — slightly high`, level: "warning", icon: <HeartPulse className="w-5 h-5" /> });
  else if (hr < 50) findings.push({ label: "Low Heart Rate", detail: `${hr} bpm — below normal`, level: "danger", icon: <HeartPulse className="w-5 h-5" /> });
  else findings.push({ label: "Heart Rate Normal", detail: `${hr} bpm`, level: "good", icon: <HeartPulse className="w-5 h-5" /> });

  // SpO2
  if (sp < 90) findings.push({ label: "Critical Oxygen Level", detail: `${sp}% — dangerously low`, level: "danger", icon: <Wind className="w-5 h-5" /> });
  else if (sp < 95) findings.push({ label: "Low Oxygen Level", detail: `${sp}% — below normal`, level: "warning", icon: <Wind className="w-5 h-5" /> });
  else findings.push({ label: "Oxygen Level Normal", detail: `${sp}%`, level: "good", icon: <Wind className="w-5 h-5" /> });

  // Temperature
  if (temp >= 39) findings.push({ label: "High Fever", detail: `${temp}°C — needs attention`, level: "danger", icon: <Thermometer className="w-5 h-5" /> });
  else if (temp >= 37.5) findings.push({ label: "Mild Fever", detail: `${temp}°C — slightly elevated`, level: "warning", icon: <Thermometer className="w-5 h-5" /> });
  else findings.push({ label: "Temperature Normal", detail: `${temp}°C`, level: "good", icon: <Thermometer className="w-5 h-5" /> });

  // Breathing Rate
  if (resp > 25 || resp < 10) findings.push({ label: "Abnormal Breathing", detail: `${resp} br/min`, level: "danger", icon: <Activity className="w-5 h-5" /> });
  else if (resp > 20) findings.push({ label: "High Breathing Rate", detail: `${resp} br/min — watch`, level: "warning", icon: <Activity className="w-5 h-5" /> });
  else findings.push({ label: "Breathing Rate Normal", detail: `${resp} br/min`, level: "good", icon: <Activity className="w-5 h-5" /> });

  // Blood Pressure
  if (sys > 160 || dia > 100) findings.push({ label: "High Blood Pressure", detail: `${sys}/${dia} mmHg`, level: "danger", icon: <Syringe className="w-5 h-5" /> });
  else if (sys > 130) findings.push({ label: "Borderline BP", detail: `${sys}/${dia} mmHg — watch`, level: "warning", icon: <Syringe className="w-5 h-5" /> });
  else findings.push({ label: "Blood Pressure Normal", detail: `${sys}/${dia} mmHg`, level: "good", icon: <Syringe className="w-5 h-5" /> });

  const dangers = findings.filter(f => f.level === "danger").length;
  const warnings = findings.filter(f => f.level === "warning").length;
  
  let overall: AnalysisResult['overall'] = "good";
  if (dangers >= 2) overall = "critical";
  else if (dangers === 1) overall = "high";
  else if (warnings >= 2) overall = "moderate";
  else if (warnings === 1) overall = "low-warning";

  const messages: Record<AnalysisResult['overall'], AnalysisResult['message']> = {
    good: { 
      label: "All Vitals Normal", 
      emoji: "✅", 
      advice: "Your vitals are all within healthy ranges. Keep it up!", 
      bg: "from-emerald-600 to-emerald-500", 
      border: "border-emerald-300",
      icon: <CheckCircle2 className="w-12 h-12 text-white" />
    },
    "low-warning": { 
      label: "Minor Concern", 
      emoji: "💛", 
      advice: "One minor reading noted. Keep an eye on it and rest well.", 
      bg: "from-amber-600 to-amber-500", 
      border: "border-amber-300",
      icon: <AlertCircle className="w-12 h-12 text-white" />
    },
    moderate: { 
      label: "Needs Monitoring", 
      emoji: "⚠️", 
      advice: "Some readings are outside normal range. See a doctor if symptoms continue.", 
      bg: "from-orange-700 to-orange-600", 
      border: "border-orange-300",
      icon: <AlertTriangle className="w-12 h-12 text-white" />
    },
    high: { 
      label: "Attention Required", 
      emoji: "🚨", 
      advice: "One or more critical readings detected. Please consult a doctor soon.", 
      bg: "from-red-600 to-red-500", 
      border: "border-red-300",
      icon: <AlertCircle className="w-12 h-12 text-white" />
    },
    critical: { 
      label: "Seek Medical Help", 
      emoji: "🆘", 
      advice: "Multiple critical readings. Please seek medical attention immediately.", 
      bg: "from-red-900 to-red-700", 
      border: "border-red-400",
      icon: <AlertCircle className="w-12 h-12 text-white" />
    },
  };

  return { findings, overall, message: messages[overall] };
}

function Field({ label, unit, hint, value, onChange, placeholder }: any) {
  const isFilled = value !== "";
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-bold text-sky-100 uppercase tracking-wider">
        {label} <span className="text-sky-300 font-medium normal-case">({unit})</span>
      </label>
      <input
        type="number"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className={`
          px-3.5 py-2.5 rounded-xl text-[15px] font-bold text-slate-900 outline-none transition-all duration-200 font-mono w-full
          ${isFilled ? 'bg-white border-2 border-sky-400 shadow-[0_0_0_3px_rgba(56,189,248,0.25)]' : 'bg-white/90 border-2 border-white/20'}
          placeholder:text-slate-400 placeholder:font-sans placeholder:font-normal
        `}
      />
      {hint && <span className="text-[10px] text-sky-300 leading-tight">{hint}</span>}
    </div>
  );
}

const LEVEL_STYLE = {
  good: { bg: "bg-emerald-50/80", border: "border-emerald-200", dot: "bg-emerald-500", text: "text-emerald-900", iconColor: "text-emerald-600" },
  warning: { bg: "bg-amber-50/80", border: "border-amber-200", dot: "bg-amber-500", text: "text-amber-900", iconColor: "text-amber-600" },
  danger: { bg: "bg-red-50/80", border: "border-red-200", dot: "bg-red-500", text: "text-red-900", iconColor: "text-red-600" },
};

function FindingRow({ icon, label, detail, level }: VitalFinding) {
  const s = LEVEL_STYLE[level] || LEVEL_STYLE.good;
  return (
    <motion.div 
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className={`flex items-center gap-3 p-3 rounded-xl border-1.5 shadow-sm ${s.bg} ${s.border}`}
    >
      <div className={`${s.iconColor}`}>{icon}</div>
      <div className="flex-1">
        <div className={`font-bold text-[13px] ${s.text}`}>{label}</div>
        <div className={`text-[12px] opacity-70 ${s.text}`}>{detail}</div>
      </div>
      <div className={`w-2.5 h-2.5 rounded-full ${s.dot}`} />
    </motion.div>
  );
}

export default function App() {
  const [form, setForm] = useState({
    age: "", heartRate: "", spo2: "",
    temperature: "", respRate: "",
    systolic: "", diastolic: "",
  });
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const set = (key: string) => (val: string) => setForm(f => ({ ...f, [key]: val }));
  const allFilled = Object.values(form).every(v => v !== "");

  function handleAnalyze() {
    if (!allFilled) return;
    setResult(analyzeVitals(form));
  }

  useEffect(() => {
    if (result) {
      document.getElementById("results")?.scrollIntoView({ behavior: "smooth" });
    }
  }, [result]);

  function handleReset() {
    setForm({ age: "", heartRate: "", spo2: "", temperature: "", respRate: "", systolic: "", diastolic: "" });
    setResult(null);
  }

  return (
    <div className="min-h-screen bg-[linear-gradient(160deg,#0f172a_0%,#1e1b4b_35%,#312e81_60%,#1e3a8a_80%,#0c4a6e_100%)] px-4 py-10 pb-20 relative overflow-hidden selection:bg-sky-500/30">
      {/* Decorative background blobs */}
      <div className="absolute w-[400px] h-[400px] bg-indigo-600 rounded-full blur-[100px] opacity-20 -top-24 -left-24 pointer-events-none" />
      <div className="absolute w-[300px] h-[300px] bg-sky-500 rounded-full blur-[100px] opacity-20 top-1/4 -right-20 pointer-events-none" />
      <div className="absolute w-[250px] h-[250px] bg-violet-500 rounded-full blur-[100px] opacity-20 bottom-24 left-1/3 pointer-events-none" />

      <div className="max-w-[560px] mx-auto relative z-10 flex flex-col gap-6">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center pb-2"
        >
          <div className="text-6xl mb-4 inline-block animate-float">
            <Stethoscope className="w-16 h-16 text-sky-400" />
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight mb-2">
            Health Monitor
          </h1>
          <p className="text-sm text-sky-200 leading-relaxed max-w-xs mx-auto">
            Enter your vitals and get an instant health risk report powered by clinical guidelines.
          </p>
        </motion.div>

        {/* Form Card */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-7 shadow-2xl"
        >
          <p className="text-[12px] font-bold text-sky-300 tracking-[0.1em] uppercase mb-5 flex items-center gap-2">
            <Activity className="w-4 h-4" /> Enter Your Vitals
          </p>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Age" unit="years" hint="Your age" value={form.age} onChange={set("age")} placeholder="e.g. 25" />
            <Field label="Heart Rate" unit="bpm" hint="Normal: 60–100" value={form.heartRate} onChange={set("heartRate")} placeholder="e.g. 72" />
            <Field label="SpO₂" unit="%" hint="Normal: 95–100%" value={form.spo2} onChange={set("spo2")} placeholder="e.g. 98" />
            <Field label="Temperature" unit="°C" hint="Normal: 36.1–37.2" value={form.temperature} onChange={set("temperature")} placeholder="e.g. 36.6" />
            <Field label="Breathing Rate" unit="br/min" hint="Normal: 12–20" value={form.respRate} onChange={set("respRate")} placeholder="e.g. 15" />
            <div className="hidden sm:block" />
            <Field label="Systolic BP" unit="mmHg" hint="Top number" value={form.systolic} onChange={set("systolic")} placeholder="e.g. 120" />
            <Field label="Diastolic BP" unit="mmHg" hint="Bottom number" value={form.diastolic} onChange={set("diastolic")} placeholder="e.g. 80" />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={!allFilled}
            className={`
              mt-6 w-full py-4 rounded-2xl border-none font-extrabold text-[15px] tracking-wide transition-all duration-300 flex items-center justify-center gap-2
              ${allFilled 
                ? 'bg-gradient-to-r from-sky-400 via-indigo-500 to-violet-500 text-white cursor-pointer shadow-lg shadow-indigo-500/40 hover:scale-[1.02] active:scale-[0.98]' 
                : 'bg-white/5 text-white/30 cursor-not-allowed'}
            `}
          >
            Analyze My Vitals <ChevronRight className="w-5 h-5" />
          </button>

          {!allFilled && (
            <p className="text-center text-[11px] text-white/30 mt-3 font-medium">
              Please fill in all fields to generate your report
            </p>
          )}
        </motion.div>

        {/* Results */}
        <AnimatePresence>
          {result && (
            <motion.div 
              id="results"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              className="flex flex-col gap-4"
            >
              {/* Overall result banner */}
              <div className={`bg-gradient-to-br ${result.message.bg} rounded-3xl p-7 border-2 ${result.message.border} shadow-xl relative overflow-hidden`}>
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  {result.message.icon}
                </div>
                <div className="flex items-center gap-4 mb-4 relative z-10">
                  <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md">
                    {result.message.icon}
                  </div>
                  <div>
                    <div className="text-[11px] font-bold text-white/70 uppercase tracking-widest mb-0.5">
                      Overall Assessment
                    </div>
                    <div className="text-2xl font-black text-white tracking-tight">
                      {result.message.label}
                    </div>
                  </div>
                </div>
                <p className="text-sm text-white/90 leading-relaxed font-medium relative z-10">
                  {result.message.advice}
                </p>
              </div>

              {/* Detailed breakdown */}
              <div className="bg-white/10 backdrop-blur-xl border border-white/15 rounded-3xl p-6 shadow-xl">
                <p className="text-[12px] font-bold text-sky-300 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Detailed Breakdown
                </p>
                <div className="flex flex-col gap-2.5">
                  {result.findings.map((f, i) => (
                    <FindingRow key={i} {...f} />
                  ))}
                </div>
              </div>

              {/* Check again button */}
              <button 
                onClick={handleReset} 
                className="w-full py-3.5 rounded-2xl border-1.5 border-white/25 bg-white/5 text-sky-100 font-bold text-sm cursor-pointer transition-all duration-200 hover:bg-white/10 flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" /> Check Again
              </button>

              <p className="text-center text-[11px] text-white/30 px-6">
                ⚠️ This tool is for informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
