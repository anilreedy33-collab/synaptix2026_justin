/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Heart, 
  Thermometer, 
  Wind, 
  Activity, 
  AlertCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Info,
  RefreshCcw,
  ArrowRight
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────
type Level = "good" | "warning" | "danger";

interface Finding {
  label: string;
  detail: string;
  level: Level;
  icon: ReactNode;
}

interface Vitals {
  age: string;
  heartRate: string;
  spo2: string;
  temperature: string;
  respRate: string;
  systolic: string;
  diastolic: string;
}

// ─── Analyze vitals ──────────────────────────────────────────────────────────
function analyzeVitals(vitals: Vitals) {
  const hr = parseFloat(vitals.heartRate);
  const sp = parseFloat(vitals.spo2);
  const temp = parseFloat(vitals.temperature);
  const resp = parseFloat(vitals.respRate);
  const sys = parseFloat(vitals.systolic);
  const dia = parseFloat(vitals.diastolic);

  const findings: Finding[] = [];

  // Heart Rate
  if (hr > 120) findings.push({ label: "High Heart Rate", detail: `${hr} bpm — above normal`, level: "danger", icon: <Heart className="w-5 h-5" /> });
  else if (hr > 100) findings.push({ label: "Elevated Heart Rate", detail: `${hr} bpm — slightly high`, level: "warning", icon: <Heart className="w-5 h-5" /> });
  else if (hr < 50) findings.push({ label: "Low Heart Rate", detail: `${hr} bpm — below normal`, level: "danger", icon: <Heart className="w-5 h-5" /> });
  else findings.push({ label: "Heart Rate Normal", detail: `${hr} bpm`, level: "good", icon: <Heart className="w-5 h-5" /> });

  // SpO2
  if (sp < 90) findings.push({ label: "Critical Oxygen Level", detail: `${sp}% — dangerously low`, level: "danger", icon: <Activity className="w-5 h-5" /> });
  else if (sp < 95) findings.push({ label: "Low Oxygen Level", detail: `${sp}% — below normal`, level: "warning", icon: <Activity className="w-5 h-5" /> });
  else findings.push({ label: "Oxygen Level Normal", detail: `${sp}%`, level: "good", icon: <Activity className="w-5 h-5" /> });

  // Temperature
  if (temp >= 39) findings.push({ label: "High Fever", detail: `${temp}°C — needs attention`, level: "danger", icon: <Thermometer className="w-5 h-5" /> });
  else if (temp >= 37.5) findings.push({ label: "Mild Fever", detail: `${temp}°C — slightly elevated`, level: "warning", icon: <Thermometer className="w-5 h-5" /> });
  else findings.push({ label: "Temperature Normal", detail: `${temp}°C`, level: "good", icon: <Thermometer className="w-5 h-5" /> });

  // Respiration
  if (resp > 25 || resp < 10) findings.push({ label: "Abnormal Breathing Rate", detail: `${resp} br/min`, level: "danger", icon: <Wind className="w-5 h-5" /> });
  else if (resp > 20) findings.push({ label: "Slightly High Breathing", detail: `${resp} br/min`, level: "warning", icon: <Wind className="w-5 h-5" /> });
  else findings.push({ label: "Breathing Rate Normal", detail: `${resp} br/min`, level: "good", icon: <Wind className="w-5 h-5" /> });

  // Blood Pressure
  if (sys > 160 || dia > 100) findings.push({ label: "High Blood Pressure", detail: `${sys}/${dia} mmHg — elevated`, level: "danger", icon: <Activity className="w-5 h-5" /> });
  else if (sys > 130) findings.push({ label: "Borderline BP", detail: `${sys}/${dia} mmHg — watch`, level: "warning", icon: <Activity className="w-5 h-5" /> });
  else findings.push({ label: "Blood Pressure Normal", detail: `${sys}/${dia} mmHg`, level: "good", icon: <Activity className="w-5 h-5" /> });

  // Overall risk
  const dangers = findings.filter(f => f.level === "danger").length;
  const warnings = findings.filter(f => f.level === "warning").length;

  const overall =
    dangers >= 2 ? "critical" :
    dangers === 1 ? "high" :
    warnings >= 2 ? "moderate" :
    warnings === 1 ? "low-warning" : "good";

  const messages: Record<string, { label: string; icon: ReactNode; color: string; bg: string; border: string; advice: string }> = {
    good: { label: "All Vitals Normal", icon: <CheckCircle2 className="w-10 h-10" />, color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200", advice: "Your vitals are all within healthy ranges. Keep it up!" },
    "low-warning": { label: "Minor Concern", icon: <Info className="w-10 h-10" />, color: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200", advice: "One minor reading noted. Keep an eye on it and rest well." },
    moderate: { label: "Needs Monitoring", icon: <AlertTriangle className="w-10 h-10" />, color: "text-orange-700", bg: "bg-orange-50", border: "border-orange-200", advice: "Some readings are outside the normal range. Consider seeing a doctor if symptoms continue." },
    high: { label: "Attention Required", icon: <AlertCircle className="w-10 h-10" />, color: "text-red-600", bg: "bg-red-50", border: "border-red-200", advice: "One or more critical readings detected. Please consult a doctor soon." },
    critical: { label: "Seek Medical Help", icon: <AlertCircle className="w-10 h-10" />, color: "text-red-800", bg: "bg-red-100", border: "border-red-300", advice: "Multiple critical readings. Please seek medical attention immediately." },
  };

  return { findings, overall, message: messages[overall] };
}

// ─── Components ──────────────────────────────────────────────────────────────

function Field({ label, unit, hint, value, onChange, placeholder }: { label: string; unit: string; hint?: string; value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
        {label} <span className="text-slate-400 normal-case font-medium">({unit})</span>
      </label>
      <input
        type="number"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className={`px-3.5 py-2.5 rounded-xl border-1.5 transition-all outline-none font-mono text-sm font-semibold
          ${value ? "border-indigo-500 bg-white" : "border-slate-200 bg-slate-50/50"}
          focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 focus:bg-white`}
      />
      {hint && <span className="text-[10px] text-slate-400 font-medium">{hint}</span>}
    </div>
  );
}

function FindingRow({ icon, label, detail, level }: Finding) {
  const styles = {
    good: "bg-emerald-50 border-emerald-100 text-emerald-800 dot-emerald-500",
    warning: "bg-amber-50 border-amber-100 text-amber-800 dot-amber-500",
    danger: "bg-red-50 border-red-100 text-red-800 dot-red-500",
  };

  const dotColors = {
    good: "bg-emerald-500",
    warning: "bg-amber-500",
    danger: "bg-red-500",
  };

  return (
    <div className={`flex items-center gap-3 border rounded-xl p-3.5 ${styles[level]}`}>
      <div className="opacity-80">{icon}</div>
      <div className="flex-1">
        <div className="font-bold text-xs">{label}</div>
        <div className="text-[11px] opacity-70 font-medium">{detail}</div>
      </div>
      <div className={`w-2 h-2 rounded-full shrink-0 ${dotColors[level]}`} />
    </div>
  );
}

export default function App() {
  const [form, setForm] = useState<Vitals>({
    age: "", heartRate: "", spo2: "",
    temperature: "", respRate: "",
    systolic: "", diastolic: "",
  });
  const [result, setResult] = useState<ReturnType<typeof analyzeVitals> | null>(null);

  const updateField = (key: keyof Vitals) => (val: string) => setForm(f => ({ ...f, [key]: val }));
  const allFilled = Object.values(form).every(v => v !== "");

  function handleAnalyze() {
    if (!allFilled) return;
    setResult(analyzeVitals(form));
    setTimeout(() => {
      document.getElementById("results")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  }

  function handleReset() {
    setForm({ age: "", heartRate: "", spo2: "", temperature: "", respRate: "", systolic: "", diastolic: "" });
    setResult(null);
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 font-sora">
      <div className="max-w-xl mx-auto flex flex-col gap-8">
        
        {/* Header */}
        <header className="text-center animate-fade-up">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-2xl shadow-sm border border-slate-100 mb-4">
            <Activity className="w-8 h-8 text-indigo-600" />
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Health Monitor
          </h1>
          <p className="text-slate-500 mt-2 text-sm font-medium">
            Enter your vitals and get an instant health risk report
          </p>
        </header>

        {/* Form Card */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100 animate-fade-up [animation-delay:100ms]">
          <div className="flex items-center gap-2 mb-6">
            <span className="text-indigo-600 font-bold text-xs uppercase tracking-widest">
              📋 Enter Your Vitals
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <Field label="Age" unit="years" hint="Your current age" value={form.age} onChange={updateField("age")} placeholder="e.g. 25" />
            <Field label="Heart Rate" unit="bpm" hint="Normal: 60–100" value={form.heartRate} onChange={updateField("heartRate")} placeholder="e.g. 72" />
            <Field label="SpO₂" unit="%" hint="Normal: 95–100%" value={form.spo2} onChange={updateField("spo2")} placeholder="e.g. 98" />
            <Field label="Temperature" unit="°C" hint="Normal: 36.1–37.2" value={form.temperature} onChange={updateField("temperature")} placeholder="e.g. 36.6" />
            <Field label="Breathing Rate" unit="br/min" hint="Normal: 12–20" value={form.respRate} onChange={updateField("respRate")} placeholder="e.g. 15" />
            <div className="hidden sm:block" /> {/* Spacer */}
            <Field label="Systolic BP" unit="mmHg" hint="Top number (e.g. 120)" value={form.systolic} onChange={updateField("systolic")} placeholder="e.g. 120" />
            <Field label="Diastolic BP" unit="mmHg" hint="Bottom number (e.g. 80)" value={form.diastolic} onChange={updateField("diastolic")} placeholder="e.g. 80" />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={!allFilled}
            className={`mt-8 w-full py-4 rounded-2xl font-extrabold text-base transition-all flex items-center justify-center gap-2
              ${allFilled 
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 active:scale-[0.98] cursor-pointer" 
                : "bg-slate-100 text-slate-400 cursor-not-allowed"}`}
          >
            Analyze My Vitals <ArrowRight className="w-5 h-5" />
          </button>
          
          {!allFilled && (
            <p className="text-center text-[11px] text-slate-400 mt-4 font-medium">
              Please fill in all fields to generate report
            </p>
          )}
        </section>

        {/* Results */}
        <AnimatePresence>
          {result && (
            <motion.div 
              id="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="flex flex-col gap-6"
            >
              {/* Overall Result Card */}
              <div className={`${result.message.bg} border-2 ${result.message.border} rounded-3xl p-6 sm:p-8 shadow-md`}>
                <div className="flex items-start gap-5">
                  <div className={result.message.color}>
                    {result.message.icon}
                  </div>
                  <div>
                    <span className={`text-[10px] font-bold uppercase tracking-widest ${result.message.color} opacity-80`}>
                      Overall Assessment
                    </span>
                    <h2 className={`text-2xl font-extrabold tracking-tight ${result.message.color} mt-0.5`}>
                      {result.message.label}
                    </h2>
                    <p className={`mt-3 text-sm font-medium leading-relaxed ${result.message.color} opacity-90`}>
                      {result.message.advice}
                    </p>
                  </div>
                </div>
              </div>

              {/* Detailed Breakdown */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100">
                <h3 className="text-slate-800 font-bold text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-slate-400" />
                  Detailed Breakdown
                </h3>
                <div className="grid grid-cols-1 gap-3">
                  {result.findings.map((f, i) => (
                    <FindingRow key={i} {...f} />
                  ))}
                </div>
              </div>

              {/* Reset Button */}
              <button 
                onClick={handleReset}
                className="w-full py-4 rounded-2xl bg-white border-2 border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-50 transition-colors flex items-center justify-center gap-2 active:scale-[0.98]"
              >
                <RefreshCcw className="w-4 h-4" />
                Check Again
              </button>

              <footer className="text-center pb-8">
                <p className="text-[10px] text-slate-400 font-medium max-w-xs mx-auto leading-relaxed">
                  ⚠️ This tool is for informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
                </p>
              </footer>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
